<?php $__env->startSection('container'); ?>

<section class="min-h-100dvh">
    <div class="flex flex-row w-full">

        <div class="flex flex-col w-1/2 lg:p-10 p-2 justify-center">
            <h2 class="lg:text-xl text-gray-400 font-pop ">Hallo i am</h2>
            <h2 class="lg:text-4xl text-yellow-500 font-pop font-bold text-lg">Your Name</h2>
            <h2 class="lg:text-8xl text-white font-bold text-xl">Web</h2>
            <h2 class="text-xl lg:text-8xl text-white font-bold pl-10 ">Developer</h2>
            <p class="text-gray-400 font-pop text-sm">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rerum commodi quisquam unde eum atque officia blanditiis reprehenderit necessitatibus aut sequi!</p>
            <a href="#services" class="bg-yellow-500 w-fit text-white font-pop p-2 my-4 rounded" >See my services</a>
        </div>

        <div class="flex flex-col w-1/2">
            <img src="img/banner.png" alt="" class="w-50">
        </div>

    </div>
</section>


<section id="about" class="w-full bg-black p-2 flex flex-col lg:flex-row">
    <div class="lg:w-1/2 flex flex-col justify-center">
        <img src="img/profile.jpg" alt="profile" class="rounded-full w-80 h-80 lg:w-96 lg:h-96 mx-auto shadow-2xl">
    </div>

    <div class="lg:w-1/2 flex flex-col mx-auto lg:justify-center my-20">
        <h1 class="text-gray-300 text-4xl font-pop">About me</h1>
        <hr class="w-32 font-bold bg-yellow-500 h-1 border-0 rounded">
        <p class="text-gray-400 mt-5">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Debitis laboriosam sequi sapiente ullam ipsam quaerat voluptatum blanditiis sunt nesciunt ab? Aliquam dolore quae ab voluptates dignissimos, fugit accusamus facere natus dolores explicabo nihil porro veniam enim nobis animi non odio ut pariatur quia unde optio. Ad quaerat asperiores excepturi voluptatum.</p>
    
        <div class="pr-5 mt-4">
            <h1 class="text-xl text-gray-300 font-pop">HTML/CSS</h1>
            <div class="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                <div class="bg-yellow-500 h-2.5 rounded-full" style="width: 80%"></div>
            </div>
        </div>
        <div class="pr-5 mt-4">
            <h1 class="text-xl text-gray-300 font-pop">Laravel</h1>
            <div class="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                <div class="bg-yellow-500 h-2.5 rounded-full" style="width: 90%"></div>
            </div>
        </div>
        <div class="pr-5 mt-4">
            <h1 class="text-xl text-gray-300 font-pop">Python</h1>
            <div class="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                <div class="bg-yellow-500 h-2.5 rounded-full" style="width: 40%"></div>
            </div>
        </div>
        <div class="pr-5 mt-4">
            <h1 class="text-xl text-gray-300 font-pop">Java</h1>
            <div class="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                <div class="bg-yellow-500 h-2.5 rounded-full" style="width: 50%"></div>
            </div>
        </div>
    </div>
</section>


<section id="services" class="w-full text-center my-20" >
    <h1 class="text-4xl text-gray-300 font-pop">Services</h1>
    <div class="flex flex-row justify-evenly flex-wrap sm:flex-nowrap">

        <div class="p-1 rounded m-2 bg-gradient-to-b from-yellow-500 to-black">
            <div class="bg-black">
                <div class="text-white text-6xl p-2"><i class="fa-solid fa-code"></i></div>
                <h1 class="text-gray-300 text-xl font-bold font-pop">HTML/CSS</h1>
                <p class="text-gray-300 text-sm">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Qui, temporibus!</p>
            </div>
        </div>         
        
        <div class="p-1 rounded m-2 bg-gradient-to-t from-yellow-500 to-black">
            <div class="bg-black">
                <div class="text-white text-6xl p-2"><i class="fa-brands fa-laravel"></i></div>
                <h1 class="text-gray-300 text-xl font-bold font-pop">Laravel</h1>
                <p class="text-gray-300 text-sm">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Qui, temporibus!</p>
            </div>
        </div>         
        <div class="p-1 rounded m-2 bg-gradient-to-b from-yellow-500 to-black">
            <div class="bg-black">
                <div class="text-white text-6xl p-2"><i class="fa-brands fa-python"></i></div>
                <h1 class="text-gray-300 text-xl font-bold font-pop">Python</h1>
                <p class="text-gray-300 text-sm">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Qui, temporibus!</p>
            </div>
        </div>         
        <div class="p-1 rounded m-2 bg-gradient-to-t from-yellow-500 to-black">
            <div class="bg-black">
                <div class="text-white text-6xl p-2"><i class="fa-brands fa-java"></i></div>
                <h1 class="text-gray-300 text-xl font-bold font-pop">Java</h1>
                <p class="text-gray-300 text-sm">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Qui, temporibus!</p>
            </div>
        </div>         
        

    </div>
</section>


<section class="w-full my-4 flex flex-col lg:flex-row items-center justify-evenly">
    <h1 class="text-6xl text-yellow-500 font-bold font-pop">Language</h1>
    <div class="flex flex-col lg:flex-row justify-evenly mt-5">

        <div class="flex flex-col justify-center text-center m-4 p-5 bg-gray-900 rounded">
            <h1 class="text-yellow-500 text-2xl font-bold font-pop">English</h1>
            <p class="text-gray-300 font-pop">Lorem ipsum dolor sit amet.</p>
        </div>
        <div class="flex flex-col justify-center text-center m-4 p-5 bg-gray-900 rounded">
            <h1 class="text-yellow-500 text-2xl font-bold font-pop">German</h1>
            <p class="text-gray-300 font-pop">Lorem ipsum dolor sit amet.</p>
        </div>
        <div class="flex flex-col justify-center text-center m-4 p-5 bg-gray-900 rounded">
            <h1 class="text-yellow-500 text-2xl font-bold font-pop">Bahasa</h1>
            <p class="text-gray-300 font-pop">Lorem ipsum dolor sit amet.</p>
        </div>

    </div>
</section>

<section id="contact" class="text-center mt-28 p-10">
    <hr class="font-bold bg-yellow-500 h-1 border-0 rounded mx-5">
    <h1 class="text-6xl text-gray-300 font-khand font-bold my-10">Let´s work together</h1>
    <p class="text-gray-300 font-pop mb-10">Lorem ipsum dolor sit amet consectetur adipisicing elit. Est, provident dignissimos. Qui totam nulla doloribus necessitatibus aspernatur facere animi minus molestiae a, adipisci alias omnis ex provident eligendi iste quasi labore id officiis? Quasi accusamus cupiditate quidem, maxime magni facilis laudantium non, ducimus iure accusantium pariatur repellendus eligendi nesciunt error!</p>
    <a href="" class="bg-yellow-500 text-white text-xl font-bold font-pop p-2 rounded">Contact me</a>
</section>


<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/welcome.blade.php ENDPATH**/ ?>